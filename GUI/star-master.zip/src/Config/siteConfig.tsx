export const USERNAME = "stardev";
export const USERPASSWORD = "stardev@123!@#";

export const API_URL =
  "http://103.10.234.158:8083/application-service/secured/v1";
export const API_URL_DATA_LAYER =
  "http://18.188.115.98:3377/application-service/secured/v1/newlayer";
export const IP = "http://103.10.234.158";
//export const IP = 'http://18.88.115.98';

// export const PORT_8080 = ':8080';
// export const PORT_8081 = ':8081';
export const PORT_8082 = ":8082";
export const PORT_8083 = ":8083";
// export const PORT_3333 = ':3333';
export const PORT_9001 = ":9002";
//export const PORT = ':3333';
export const PORT = ":3333";
export const APP_SERVICE = "/application-service/secured/v1";
export const APP_SERVICE_V="/application-service/secured"
export const LAYERS = "/layers";
export const NEW_LAYER = "/newlayer";
export const LANDMARKS = "/landmarks";
//export const LANDMARKS = '/landmark';
export const NOTIFICATION = "/notification";
export const USERS = "/users";
export const CUSTOMERS = "/customers";
export const GEOFENCE = "/geofence";
export const ASSETS = "/assets";

export const USER_ASSET = "/user-assets";
export const CUSTOMER_ASSET = "/customer-assets";
export const LATEST_ASSETS = "/assets/latestdata";
export const GET_REPORT = "/getReport";
export const GET_FLIGHT_DETAILS = "/getFlightDetails";
export const GET_FLIGHTS_FOR_ASSET = "/getFlightsForAsset";
export const AUTHENTICATE = "/users/user/authenticate";
export const GET_REPORT_ENG_MAINTAINANCE = "/eofsr_em";
export const GET_REPORT_ENG_CONDITION = "/EOFSR_ENGI_COND_MONI";

export const GET_FLIGHT_DETAILS_FORGRAPH = "/getFlightGraphData";

export const GET_REPORT_FINANCE_ADMIN = "/EOFSR_FINA_ADMI";
export const GET_REPORT_FLIGHT_OPERATION = "/EOFSR_FLIG_OPER";
export const GET_REPORT_FLIGHT_SAFETY = "/EOFSR_FLIG_SAFE";
export const GET_REPORT_FLIGHT_MOQA = "/EOFSR_MOQA";
export const GET_REPORT_FLIGHT_FOQA = "/EOFSR_FOQA";
export const SEVERITY = "/severity";
export const EVENT_TYPES = "/eventTypes";
export const GET_EVENT_LIST = "/getEventList";
export const GET_LOCATION = "/getLocation";
export const GET_EVENT_FOR_FLIGHT = "/getEventForLatestFlight";

export const EVENT_BASED_NOTIFICATION="/event-notifications";
export const EVENT_LIST_DROPDOWN ="/eventNotification/dropdown";
export const GET_GRAPH_DROPDOWN = "/graph/dropdown";
export const GET_SUMMARY_COUNT = "/summaryCount";
export const GET_LatestFlightsForAssetDateOrLimit =
  "/getLatestFlightsForAssetDateOrLimit";

export const GOOGLE_API_KEY = "AIzaSyC9gF0NXH_KTIccE1w1a2_BpLqW0KuECb8";

export const BARON_BASE_URL = "http://api.velocityweather.com/v1";
export const BARON_KEY = "ExsvAOdNtyoS";
export const BARON_SECRET = "MZZhHLWRtgPs8NfIv8piiODqov4SbZYrfpOqPj0tyn";
export const AirCraftDetailInterval = 30000;


