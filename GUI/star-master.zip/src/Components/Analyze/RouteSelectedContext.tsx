import { createContext } from 'react';

export const RouteSelectedContext = createContext({});
