import React from "react";

const GraphConfiguration = () => {
  return <>GraphConfiguration</>;
};

export default GraphConfiguration;
